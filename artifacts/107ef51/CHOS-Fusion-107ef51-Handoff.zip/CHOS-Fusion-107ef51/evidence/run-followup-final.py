import subprocess,pathlib,json
root=pathlib.Path('/workspace/CHOS-Second-Variant');out=pathlib.Path('/workspace/chos-evidence')
fw='/workspace/chos-tools/root/usr/share/AAVMF/AAVMF_CODE.fd';data='/workspace/chos-tools/root/usr/share/qemu'
cases=[
 ('followup-final-vmx-http',['tests/qemu_network.py']),
 ('followup-final-virtio-http',['tests/qemu_network.py','--net-model','virtio']),
 ('followup-final-console-uefi',['tests/qemu_console.py']),
 ('followup-final-console-direct',['tests/qemu_console.py','--mode','direct']),
 ('followup-final-install',['tests/qemu_installer.py','--keyboard','--supported-mode']),
 ('followup-final-install-error',['tests/qemu_installer.py','--write-fault']),
 ('followup-final-vmx-native',['tests/qemu_platform.py','--mode','uefi','--pci-virtio','--net-model','vmxnet3','--tablet','--memory','2G','--hub-depth','2','--firmware',fw,'--qemu-data',data]),
 ('followup-final-direct',['tests/qemu_platform.py','--qemu-data',data]),
]
results=[]
for name,args in cases:
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['python3']+args+['--out',str(out/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit_code':r.returncode});(out/'followup-final-runs.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True)
