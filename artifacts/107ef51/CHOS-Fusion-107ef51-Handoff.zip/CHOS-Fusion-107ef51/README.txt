CHOS Fusion installed-system follow-up 107ef51
Source commit: 107ef511cb076969bbc45a9fd162ff07db280304

Restart now requests firmware PSCI reset, rather than jumping back into the old
kernel. Shutdown displays Shutting down... for at least five seconds, flushes
storage and requests real system-off. Returned/absent services and failed flushes
report errors rather than pretending the machine powered off.

Installed NVMe CHFS is automatically writable after live identity/geometry checks.
Setup is hidden on installed boots. Use the ISO for a separately confirmed reinstall.
Unknown/blank disks are never autoformatted. The installer erases its selected disk.
There is no automatic installed-system updater: evaluate this ISO on a fresh
virtual disk or preserve your existing VM/data before reinstalling.

VMXNET3 (PCI15ad:07b0) is supported through a modular Ethernet backend, using the
same DHCP, DNS, TCP and HTTP stack as VirtIO. Other NIC IDs need their own backend.
The UEFI browser no longer mistakes a temporary empty read for EOF. HTTP fixtures,
relative redirects and DNS pass; HTTPS still requires verified TLS in Stage3.
This does not certify public-site access or Fusion's actual network connection.

Console history: wheel, Page Up/Down, Home=oldest, End=live tail. Typing returns to
the current prompt; clear removes history. Built-in Console retains512 old rows;
EL0 Console retains256. Run pci net and netstatus for compact NIC/driver/DHCP/IP/DNS.
An explicit session DNS override is available via dnsserver A.B.C.D after DHCP.

Use one CPU,2GiB RAM,one disposable NVMe virtual disk,ARM64 UEFI. Prior c4672fb
installation/disk-only boot is user-confirmed in Fusion. This follow-up needs a
Fusion retest of actual reset/power-off, automatic writes, saved resolution,
network and Console history. No new Fusion run was possible in this cloud.

Final clean source 107ef51: all included QEMU profiles pass, including real in-guest
installation, ISO removal, disk-only boot, automatic persistence, actual firmware
reset, five-second shutdown, injected write error, VMXNET3/VirtIO HTTP+DNS fixtures,
Console scrolling and direct/native input/storage/network regressions. Host and
ASan/UBSan pass. See evidence/FOLLOWUP_FINAL_RESULTS.json and docs.

All runtime disks/firmware variables/captures are excluded. The optional prepared
image is the official generated distribution image; it is not a mutated test disk.
Unzip, verify SHA256SUMS, and decompress .gz files before using them.
