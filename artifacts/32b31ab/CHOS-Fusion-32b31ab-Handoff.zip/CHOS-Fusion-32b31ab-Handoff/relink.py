#!/usr/bin/env python3
import pathlib,json,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
command=json.loads((root/'relink-argv.json').read_text())
command=[v.replace('@ROOT@',str(root)) for v in command]
# Optionally select a compatible Clang installation through argv[1].
if len(sys.argv)>1:command[0]=sys.argv[1]
subprocess.run(command,cwd=root,check=True)
print(root/'relinked.elf')
