#!/usr/bin/env python3
import pathlib,json,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
command=json.loads((root/'fixture/compile-argv.json').read_text())
command=[v.replace('@ROOT@',str(root)) for v in command]
if len(sys.argv)>1:command[0]=sys.argv[1]
subprocess.run(command,cwd=root,check=True)
