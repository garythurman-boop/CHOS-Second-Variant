import sys,argparse,pathlib,time,json,hashlib,subprocess,tempfile
sys.path.insert(0,'tests')
from qemu_platform import Guest,wait
out=pathlib.Path('/workspace/chos-evidence/stage2-release-cancel');out.mkdir(exist_ok=False)
disk=out/'disposable.img'
with disk.open('xb') as stream:stream.truncate(256*1024*1024)
a=argparse.Namespace(mode='uefi',uefi_kernel=pathlib.Path('build/uefi-kernel/chos.elf'),iso=pathlib.Path('build/chos-0.30.0.iso'),memory='2G',qemu_data=pathlib.Path('/workspace/chos-tools/root/usr/share/qemu'),rtc_base=None,trace=False,firmware=pathlib.Path('/workspace/chos-tools/root/usr/share/AAVMF/AAVMF_CODE.fd'),no_usb=False,usb_pci_bus=0,xhci_model='qemu-xhci',pci_virtio=True,storage_error=False,nvme=True,no_rng=False,hub_depth=0,empty_usb=False,tablet=True)
with tempfile.TemporaryDirectory() as temporary:
 source=pathlib.Path(temporary)/'offset.c';binary=pathlib.Path(temporary)/'offset'
 source.write_text('#include <stddef.h>\n#include <stdio.h>\n#include "chos/installer_io.h"\nint main(void){printf("%zu",offsetof(chos_install_job_t,state));}\n')
 subprocess.run(['cc','-Iinclude',str(source),'-o',str(binary)],check=True)
 offset=int(subprocess.check_output([str(binary)],text=True))
g=Guest(a,out,disk)
def key(code):g.hmp('sendkey '+code);time.sleep(.15)
def state():return int.from_bytes(g.block('installation',offset=offset,size=4),'little')
try:
 wait(lambda:'Initial CHOS GUI frame rendered' in g.text(),45,'desktop')
 wait(lambda:g.symbol('splash_active')==0,10,'splash');key('i')
 for _ in range(4):key('ret')
 before=hashlib.sha256(disk.read_bytes()).hexdigest();key('esc')
 assert state()==7 and hashlib.sha256(disk.read_bytes()).hexdigest()==before,'Pre-write cancel must leave disk unchanged'
 key('i')
 for _ in range(6):key('ret')
 wait(lambda:state()==2,3,'installation writing');key('esc');wait(lambda:state()==7,3,'mid-install cancel')
 stopped=hashlib.sha256(disk.read_bytes()).hexdigest();assert stopped!=before
 time.sleep(.5);assert hashlib.sha256(disk.read_bytes()).hexdigest()==stopped,'Cancelled job kept writing'
 g.screen('cancelled-desktop');key('i')
 for _ in range(2):key('ret')
 assert state()==1,'Cancelled job must allow fresh explicit target selection'
 assert hashlib.sha256(disk.read_bytes()).hexdigest()==stopped,'Retry selection wrote without confirmation'
 g.screen('retry-target')
 (out/'result.json').write_text(json.dumps({'status':'PASS','checks':['Escape before confirmation leaves disk unchanged','Escape during writing stops subsequent writes','cancelled partial disk is not rolled back','reopen and explicit reselection work without unconfirmed writes']},indent=2))
except Exception:
 g.screen('failure');raise
finally:g.close()
