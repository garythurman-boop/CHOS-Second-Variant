CHOS Stage 2 installation candidate c4672fb
Source commit: c4672fb9af49ba221d1c3b16b26cc1a5974ebef1

Boot CHOS-Fusion-c4672fb.iso in an isolated ARM64 UEFI Fusion VM with one CPU,
2 GiB RAM and exactly one DISPOSABLE NVMe virtual disk (512-byte sectors).
Actual Fusion testing of this new installer is still required; all runtime
acceptance evidence in this package comes from QEMU/AAVMF.

Diagnostics -> Detect NVMe (read only) makes existing CHFS files available.
Enable CHFS writes... -> Confirm file writes permits persistent changes.
Diagnostics -> Install CHOS... or I on desktop opens the real installer.
Explicitly select/check the target identity/capacity, review partitions,
acknowledge ALL data loss and select Install. Never select valuable media.
Setup writes and verifies GPT, FAT32 EFI loader/kernel files and CHFS. Cancel
stops further work but does not undo earlier writes. Wait for verified success,
shut down, detach ISO and boot the NVMe disk alone. The installed volume mounts
read only; explicitly enable writes to save files/settings.

Settings changes logical desktop size immediately. On an installed writable
volume it also saves the physical firmware mode request; restart to apply an
enumerated GOP mode. Unsupported/corrupt requests retain a safe mode. No runtime
firmware calls or arbitrary live scanout changes are claimed.

The browser now opens on UEFI through the shared cooperative kernel adapter.
HTTP/links/redirects/text layout remain; HTTPS/TLS and native Fusion networking
are unavailable. Other Stage 1 Pi/laptop/IOMMU gates are still open.

Both pointer and keyboard ISO -> guest install -> ISO removed -> disk-only boot
-> installed file write -> reboot/persistence paths pass. A supported physical
1024x768 mode, unsupported-mode fallback, automatic read-only boot mounting and
boot-volume erase protection pass. Actual NVMe write-error injection reports
failure without false success or disk changes, and GUI/timer stay responsive.
Direct, nested native USB/clock/PCI, and terminal panic regressions pass.
See evidence/STAGE2_FINAL_RESULTS.json and included install/validation guides.

Source ZIP, exact ISO, kernels, EFI loader and official prepared distribution
image are included. No per-test mutable disks or firmware variables are included.
Decompress .gz files before use. Verify SHA256SUMS after extraction.
The prepared image is optional host-built distribution media; acceptance used
an actual in-guest graphical install, not a prepared-image substitute.

Build: make CC=clang LD=ld.lld -j4 all uefi-iso install-disk-image
Checks: make test CC=clang LD=ld.lld -j1
        make test-sanitize CC=clang LD=ld.lld -j1
        make qemu-smoke CC=clang LD=ld.lld
        python3 tests/qemu_installer.py --out /workspace/chos-evidence/NEW --keyboard --supported-mode
Use fresh disposable output paths. See docs/INSTALL_GUIDE.md for limitations.
