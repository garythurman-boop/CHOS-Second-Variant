# Revised Stage 3: internet platform architecture

The user-provided [revised specification](STAGE3_REVISED_PROMPT.md) supersedes the
Stage 3 section of the earlier Word document. Full modern web rendering and real
wireless support remain completion requirements. This document does not certify
an engine port, Wi-Fi or an integrated production browser TLS policy on CHOS.

## Existing system to preserve

Direct and UEFI now have bounded isolated EL0 applications and a single-CPU
preemptive scheduler. UEFI retains its relocated PIE kernel, native PCI USB/NVMe/
GOP, identity DMA and disabled data caching, with CPU MMU isolation enabled in its
scheduled profile. New source still needs independent Fusion qualification.
CHCX retains its64KiB bound; static native ELF has a2MiB image span and4MiB owned
frame quota. There are four processes,32KiB main stacks and up to three secondary
join records per process. Native C allocation/errno, pthread synchronization,
private futexes, bounded process messages and explicit compiler-emulated C/C++ TLS
now have guest evidence. They do not provide engine-sized heaps/images, complete
POSIX/events/shared-memory/descriptor passing, a dynamic loader, C++ standard
library or a modern-engine sandbox. Native MbedTLS1.2/1.3 clients validate peers;
production trust/time/reseed policy and engine integration remain open. These are
implementation dependencies, not external-hardware blockers. A Linux ARM64 browser
binary cannot run on this ABI.

Preserve the validated direct/UEFI boot, installed NVMe/CHFS, genuine installer,
power lifecycle, native USB, GOP sizing and existing VirtIO paths. Networking has
DHCPv4, ARP, ICMP, bounded DNS A and four outbound TCP sockets, with single selected
VirtIO or VMXNET3 backend. The HTTP preview browser has URL/redirect/parser tests
and now correct nonblocking UEFI adapters. It remains a recovery/diagnostic app;
it is not the revised modern browser deliverable. No TLS/certificate validation,
IPv6, wireless driver/authentication or Network Manager is implemented initially.

## Immediate implementation order

1. Close Fusion's identified controller gap: PCI 8086:10d3 (82574L/e1000e).
   Keep device-specific ring/resource handling behind the common Ethernet API.
   Validate queues, link, DHCP, DNS and HTTP in an actual AArch64 QEMU e1000e guest;
   distinguish that evidence from the unavailable Fusion host.
2. Introduce an OS-owned network configuration/status service. Centralize link
   transitions, static/DHCP validation, route/resolver state and reconnection.
   The privileged shell configures it; browsers only consume sockets/status.
   Add persistent checked profiles and a functional graphical Network Manager.
3. Evaluate maintained browser engines and select a port architecture from actual
   upstream requirements. Implement the necessary isolated user runtime and I/O
   services; do not execute a modern engine or untrusted JavaScript in the UEFI
   kernel GUI loop. W^X, content isolation, bounded memory and preemption need real
   tests before hostile content is admitted. Do not replace the modern-engine goal
   with a text parser, host renderer or remote rendering service.
4. Integrate maintained, pinned TLS with verified entropy/time/trust roots, failure
   fixtures and update policy. VirtIO RNG has live QEMU evidence but Fusion entropy
   remains unavailable. Firmware-clock snapshots are not an authenticated network
   time service. HTTPS remains blocked until all verification prerequisites work.
5. Add explicitly selected wireless hardware through real bus/firmware/802.11 and
   WPA services. No device scan/profile UI may invent hardware or networks. Pi 5
   and laptop controller selection needs actual inventory/firmware evidence.
6. Expand IPv6, multiple interfaces/routes, browser APIs/conformance, downloads,
   persistent web storage and resilience; benchmark real guests and keep all
   unfinished requirements visible.

## Constraints and test matrix

The current target remains one CPU, 2 GiB RAM, identity DMA without native IOMMU.
Modern engines need larger address spaces, multiple isolated processes/threads,
substantial heap/stack growth, filesystem and IPC primitives and software-rendering
or GPU backend integration. Raising an image-size constant alone does not supply
those capabilities. Resource bounds and allocation-failure handling must accompany
runtime expansion. No modern-engine performance numbers exist yet.

| Platform | Available evidence/environment | Required independent gates |
|---|---|---|
| QEMU AArch64 direct | Live MMU/EL0, VirtIO Ethernet/RNG, CHFS, GUI | Retain regressions; add service/TLS/engine/IPv6 fixtures |
| QEMU AArch64 UEFI | Live native USB/NVMe/GOP, VirtIO/VMXNET3 | e1000e traffic, reconnect, manager, installer/power regression; isolated runtime |
| Fusion on M1 | User confirms prior lifecycle fixes and now Ethernet/example.com after 54b9731; NIC 8086:10d3 | Reconnect/failure tests; secure entropy; modern runtime/browser |
| Raspberry Pi 5 | Board unavailable | Real boot/IOMMU/DMA, Ethernet and selected Wi-Fi chipset/firmware/authentication |
| ARM64 laptop | Model/inventory unavailable | Explicit controller/firmware, Wi-Fi, ACPI/DMA, real browser/isolation |

Every completion requirement remains open until backed by working implementation
and appropriate runtime evidence. Host tests and QEMU Ethernet do not certify
Fusion, physical wireless or browser standards compliance.

The first network milestone is published as build-54b9731. The next runtime
source-only iteration adds the bounded EL0 mapping primitive documented in
USER_MEMORY.md; it does not provide a modern engine or change the full-stage
completion criteria.

The selected physical wireless target is now the Pi 5 onboard CYW43455 family,
not a Fusion virtual Ethernet adapter. See PI5_WIRELESS.md for pinned Raspberry Pi
firmware evidence and the SDIO2/platform/firmware/authentication dependencies.

IPv6 control-plane source progress is documented in IPV6_CONTROL_PLANE.md. It
preserves the IPv4 stack and adds a pinned lwIP core for actual DAD/SLAAC/ND/MLD/
ICMPv6. TCP6, DNS6/DHCP6, multi-interface routing and complete IPv6 settings remain
open; this is not full IPv6 browser support or completion of the revised stage.

The next runtime prerequisite is implemented in NATIVE_EXECUTABLES.md. Native
static CHOS-ABI ELF64 images can span up to2MiB with separate permissions and
sparse mappings; CHCX limits and existing owned-frame quotas remain. This is
validated direct EL0 support, not a complete modern browser or UEFI user runtime.
Binary publication is held by the latest user instruction until full Stage3
completion and thorough testing; source-only work continues.

Current source adds a bounded UEFI CPU/process isolation profile while retaining
identity DMA with data caching off. See [runtime contract and QEMU evidence](UEFI_PROCESS_RUNTIME.md).
This does not establish Fusion qualification for these new changes, native IOMMU
ownership, a modern browser, verified TLS or live wireless support. The binary
publication hold remains active until the complete revised Stage 3 passes.

Current runtime source now has tested [C++ synchronization](NATIVE_CXX_SYNCHRONIZATION.md)
and bounded [standard C++ threads](NATIVE_CXX_THREADS.md), in addition to the prior
native TLS, floating-point and static CRT profiles. The actual ICU threading
component runs; full target ICU and the modern engine still do not. Follow
STAGE3_CURRENT_RESULTS.md and BROWSER_ENGINE_PORT.md for current acceptance gates;
these component results do not complete the engine, security or wireless scope.
