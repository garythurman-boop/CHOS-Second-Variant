#!/usr/bin/env python3
"""Live QEMU acceptance checks. Always uses disposable disk/firmware copies.
Screenshots prove visible changes; QMP injects real emulated input devices.
No QMP event is injected directly into a CHOS API.
"""
import argparse,hashlib,json,math,os,pathlib,re,shutil,socket,struct,subprocess,tempfile,time
from guest_iso_artifacts import verify_iso_kernel,verify_installed_kernel
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Guest:
    def __init__(self,args,out,disk):
        self.out=out;self.log=out/'serial.log';self.logfile=self.log.open('wb')
        self.args=args;self.events=[]
        original=args.kernel if args.mode=='direct' else args.uefi_kernel
        elf=out/'kernel.elf';shutil.copyfile(original,elf)
        iso=out/'boot.iso'
        if args.mode=='uefi':shutil.copyfile(args.iso,iso)
        artifacts={'kernel_sha256':hashlib.sha256(elf.read_bytes()).hexdigest()}
        if args.mode=='uefi':
            artifacts['iso_sha256']=hashlib.sha256(iso.read_bytes()).hexdigest()
            artifacts.update(verify_iso_kernel(iso,elf))
        elif args.mode=='installed':
            artifacts.update(verify_installed_kernel(disk,elf))
        (out/'artifacts.json').write_text(json.dumps(artifacts,indent=2))
        self.symbols={}
        for line in subprocess.check_output(['nm',str(elf)],text=True).splitlines():
            parts=line.split()
            if len(parts)==3:self.symbols[parts[2]]=int(parts[0],16)
        self.sockpath=out/'qmp.sock'
        cmd=['qemu-system-aarch64','-M','virt,gic-version='+('2' if args.mode=='direct' else '3'),
             '-cpu','cortex-a72','-m',args.memory,'-display','none','-no-reboot',
             '-global','virtio-mmio.force-legacy=false','-serial','stdio',
             '-qmp',f'unix:{self.sockpath},server=on,wait=off']
        if getattr(args,'allow_reboot',False):cmd.remove('-no-reboot')
        if args.qemu_data: cmd+=['-L',str(args.qemu_data)]
        if getattr(args,'gdb_socket',None):
            cmd+=['-gdb','unix:'+str(args.gdb_socket)+',server=on,wait=off']
        if args.rtc_base:cmd+=['-rtc','base='+args.rtc_base+',clock=vm']
        if args.trace:cmd+=['-trace','enable=virtio_*,file='+str(out/'virtio.trace')]
        if args.mode=='direct':
            cmd+=['-device',f'loader,file={elf},cpu-num=0','-device','virtio-gpu-device',
                  '-device','virtio-keyboard-device','-device','virtio-mouse-device',
                  '-drive',f'if=none,file={disk},format=raw,id=disk','-device','virtio-blk-device,drive=disk',
                  '-netdev',getattr(args,'netdev','user,id=net'),'-device','virtio-net-device,netdev=net']
            if not args.no_rng: cmd+=['-object','rng-random,filename=/dev/urandom,id=rng','-device','virtio-rng-device,rng=rng']
        else:
            vars=out/'vars.fd';shutil.copyfile(args.firmware.parent/'AAVMF_VARS.fd',vars)
            cmd+=['-drive',f'if=pflash,format=raw,readonly=on,file={args.firmware}',
                  '-drive',f'if=pflash,format=raw,file={vars}','-device','ramfb']
            if not args.no_usb:
                for bus in range(1,args.usb_pci_bus+1):
                    cmd+=['-device',f'pcie-root-port,id=usb-rp{bus},bus=pcie.0,addr={bus:x},chassis={bus},port={bus}']
                cmd+=['-device',args.xhci_model+',id=xhci'+(',bus=usb-rp'+str(args.usb_pci_bus) if args.usb_pci_bus else '')]
            if args.pci_virtio:
                disk_backend=str(disk)
                if args.storage_error:
                    config=out/'blkdebug.conf';config.write_text('[inject-error]\nevent = "write_aio"\nerrno = "5"\nimmediately = "on"\nonce = "off"\n')
                    disk_backend='blkdebug:'+str(config)+':'+str(disk)
                cmd+=['-drive',f'if=none,file={disk_backend},format=raw,id=storage','-device',
                      'nvme,serial=CHOS-DISPOSABLE,drive=storage' if args.nvme else 'virtio-blk-pci,disable-legacy=on,drive=storage',
                      '-netdev',getattr(args,'netdev','user,id=net'),'-device',(getattr(args,'net_model','virtio')+',id=nic,netdev=net,romfile=' if getattr(args,'net_model','virtio') in ['vmxnet3','e1000e'] else 'virtio-net-pci,id=nic,disable-legacy=on,netdev=net')]
                if not args.no_rng:cmd+=['-object','rng-random,filename=/dev/urandom,id=rng','-device','virtio-rng-pci,disable-legacy=on,rng=rng']
            else:cmd+=['-net','none']
            self.usb_bus='xhci.0';self.mouse_port=None
            path='1'
            for depth in range(0 if args.no_usb or args.empty_usb else args.hub_depth):
                cmd+=['-device',f'usb-hub,id=hub{depth},bus=xhci.0,port={path}']
                if depth+1<args.hub_depth:path+='.1'
            keyboard_port=',port='+path+'.1' if args.hub_depth else ''
            if args.hub_depth:self.mouse_port=path+'.2'
            mouse_port=',port='+self.mouse_port if self.mouse_port else ''
            if not args.no_usb and not args.empty_usb:
                cmd+=['-device','usb-kbd,bus=xhci.0,id=kbd'+keyboard_port,
                      '-device',('usb-tablet' if args.tablet else 'usb-mouse')+',bus=xhci.0,id=mouse'+mouse_port]
            if args.mode=='uefi': cmd+=['-device','virtio-scsi-device,id=scsi',
                  '-drive',f'if=none,file={iso},format=raw,media=cdrom,id=cd','-device','scsi-cd,drive=cd']
            elif not args.pci_virtio: cmd+=['-drive',f'if=none,file={disk},format=raw,id=disk','-device','virtio-blk-device,drive=disk']
        if getattr(args,'net_capture',False):cmd+=['-object',f'filter-dump,id=capture,netdev=net,file={out}/network.pcap']
        (out/'command.json').write_text(json.dumps(cmd,indent=2))
        self.started=time.monotonic()
        self.process=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=self.logfile,stderr=subprocess.STDOUT)
        self.sock=socket.socket(socket.AF_UNIX);self.sock.settimeout(3)
        wait(lambda:self.sockpath.exists(),5,'QMP startup')
        self.sock.connect(str(self.sockpath));self.f=self.sock.makefile('rwb',buffering=0);self.f.readline();self.qmp('qmp_capabilities')
    def text(self): return self.log.read_text(errors='replace')
    def qmp(self,execute,**args):
        self.f.write(json.dumps({'execute':execute,'arguments':args}).encode()+b'\n')
        while True:
            r=json.loads(self.f.readline())
            if 'event' in r:self.events.append(r)
            if 'error' in r: raise RuntimeError(r)
            if 'return' in r:return r['return']
    def hmp(self,c):return self.qmp('human-monitor-command',**{'command-line':c})
    def block(self,name,offset=0,size=4):
        address=self.symbols[name]+offset
        if self.args.mode!='direct':
            matches=re.findall(r'Kernel physical base: (0x[0-9a-f]+)',self.text())
            match=matches[-1] if matches else None
            if not match: return 1
            address+=int(match,16)-self.symbols['__kernel_start']
        target=self.out/'probe.bin'
        result=self.hmp(f'pmemsave {address:#x} {size} "{target}"')
        if result:raise AssertionError(result)
        return target.read_bytes()
    def symbol(self,name,offset=0):return int.from_bytes(self.block(name,offset),'little')
    def window(self):
        view=self.symbol('view');data=self.block('window_manager',size=12*64)
        for offset in range(0,len(data),64):
            row=struct.unpack('<i4xQiiiiI7i',data[offset:offset+64])
            if row[0]==view and row[7]:
                return dict(id=view,x=row[2],y=row[3],width=row[4],height=row[5],minimized=row[8],maximized=row[9])
        raise AssertionError('No visible foreground window')
    def serial(self,c):
        self.process.stdin.write((c+'\n').encode());self.process.stdin.flush()
    def terminal(self):return self.block('terminal_lines',size=69*29).decode('ascii',errors='replace').replace('\x00','\n')
    def type(self,command,enter=True):
        keys={'.':'dot','/':'slash','-':'minus',' ':'spc'}
        for c in command:
            self.hmp('sendkey '+keys.get(c,c));time.sleep(.055)
        if enter:self.hmp('sendkey ret');time.sleep(.1)
    def screen(self,name,full=False):
        p=self.out/(name+'.ppm');self.qmp('screendump',filename=str(p));data=p.read_bytes()
        # Compare only canvas, excluding the RTC taskbar clock.
        pixels=data.split(b'\n',3)[3];return pixels if full else pixels[:800*540*3]
    def cpu_ticks(self):
        fields=pathlib.Path(f'/proc/{self.process.pid}/stat').read_text().split()
        return int(fields[13])+int(fields[14])
    def close(self):
        self.process.terminate()
        try:self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=3)
        self.logfile.close();self.sock.close()
def wait(predicate,seconds,description):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if predicate():return
        time.sleep(.02)
    raise AssertionError('timeout: '+description)
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode',choices=['direct','uefi','installed'],default='direct')
    ap.add_argument('--kernel',type=pathlib.Path,default=ROOT/'build/chos.elf')
    ap.add_argument('--iso',type=pathlib.Path,default=ROOT/'build/chos-0.30.0.iso')
    ap.add_argument('--firmware',type=pathlib.Path)
    ap.add_argument('--disk',type=pathlib.Path,default=ROOT/'build/qemu-smoke-disk.img')
    ap.add_argument('--out',type=pathlib.Path,required=True)
    ap.add_argument('--qemu-data',type=pathlib.Path)
    ap.add_argument('--hub-depth',type=int,choices=range(0,5),default=0)
    ap.add_argument('--tablet',action='store_true')
    ap.add_argument('--clock-test',action='store_true')
    ap.add_argument('--rtc-base')
    ap.add_argument('--pci-virtio',action='store_true')
    ap.add_argument('--net-model',choices=['virtio','vmxnet3','e1000e'],default='virtio')
    ap.add_argument('--trace',action='store_true')
    ap.add_argument('--nvme',action='store_true')
    ap.add_argument('--no-usb',action='store_true')
    ap.add_argument('--empty-usb',action='store_true')
    ap.add_argument('--xhci-model',choices=['qemu-xhci','nec-usb-xhci'],default='qemu-xhci')
    ap.add_argument('--usb-pci-bus',type=int,choices=range(0,11),default=0)
    ap.add_argument('--storage-error',action='store_true')
    ap.add_argument('--stress',type=int,default=0,help='additional mixed input/storage cycles')
    ap.add_argument('--memory',default='512M')
    ap.add_argument('--uefi-kernel',type=pathlib.Path,default=ROOT/'build/uefi-kernel/chos.elf')
    ap.add_argument('--timer-fault',action='store_true')
    ap.add_argument('--baseline',action='store_true');ap.add_argument('--no-rng',action='store_true')
    args=ap.parse_args()
    if args.nvme:args.pci_virtio=True
    if (args.no_usb or args.empty_usb) and args.mode=='direct':ap.error('USB absence profiles require firmware boot')
    if args.storage_error and not args.nvme:ap.error('--storage-error requires --nvme and an experimental kernel')
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    # Refuse to overwrite prior evidence or a user disk.
    if (out/'serial.log').exists():raise SystemExit('Use a new --out directory to preserve evidence')
    disk=out/'disposable.img'
    if args.mode!='uefi' or args.pci_virtio:shutil.copyfile(args.disk,disk)
    if args.mode=='direct' and not args.baseline:
        subprocess.run(['python3',str(ROOT/'tools/mkchfs.py'),'put',str(disk),'/BIN/RNGTEST.CHX',str(ROOT/'build/userland/rng_test.chcx')],check=True)
    g=None;result={'mode':args.mode,'checks':[]}
    try:
        g=Guest(args,out,disk)
        marker='chos> ' if args.mode=='direct' else '[OK] Initial CHOS GUI frame rendered.'
        wait(lambda:marker in g.text(),45,'guest desktop and console')
        result['kernel_ready_seconds']=round(time.monotonic()-g.started,3)
        wait(lambda:g.symbol('splash_active')==0,10,'minimum splash finished')
        time.sleep(.1)
        result['desktop_ready_seconds']=round(time.monotonic()-g.started,3)
        if args.mode!='direct':
            if not args.no_usb and not args.empty_usb:
                wait(lambda:g.symbol('online')==2,10,'USB HID enumeration through root/hub topology')
            if args.usb_pci_bus:
                assert re.search(r'PCI 0000:'+format(args.usb_pci_bus,'02x')+r':.*class 0c:03',g.text()),'xHCI must actually enumerate on the requested nonzero bus'
                result['checks']+=['PCI xHCI discovery through bus '+str(args.usb_pci_bus)+' bridges']
            assert 'IRQ delivery enabled after initial desktop frame' in g.text()
            if args.timer_fault: assert 'Timer IRQ delivery did not progress' in g.text()
            else: assert 'Timer IRQ delivery verified' in g.text()
        else:
            if not args.baseline:
                g.serial('rng-test')
                expected='[FAIL] RNG hardware bytes unavailable' if args.no_rng else '[ OK ] RNG received 32 hardware bytes'
                wait(lambda:expected in g.text(),5,'actual RNG receive / missing-device failure')
                g.serial('exec /BIN/RNGTEST.CHX'+(' missing' if args.no_rng else ''))
                expected='[ OK ] EL0 RNG validation and '+('missing-device failure' if args.no_rng else 'hardware receive')+' passed'
                wait(lambda:expected in g.text(),5,'EL0 RNG pointer/length/guard and entropy contract')
                result['checks']+=['EL0 RNG invalid pointers, length bound, guard bytes and '+('missing device' if args.no_rng else 'hardware receipt')]
            g.serial('fswrite /STAGE1.TXT stage1-persistence')
            wait(lambda:'file written (directory committed' in g.text(),5,'CHFS write/flush')
            g.serial('fsread /STAGE1.TXT')
            wait(lambda:g.text().count('stage1-persistence')>=2,5,'CHFS readback')
            g.serial('ping 10.0.2.2')
            next_query=[0.0]
            def ping_replied():
                if time.monotonic()>next_query[0]:
                    g.serial('netstatus');next_query[0]=time.monotonic()+.5
                return 'Ping: reply received' in g.text()
            wait(ping_replied,10,'actual DHCP/ARP/ICMP exchange')
            result['checks']+=['CHFS write/flush/read','DHCP/ARP/ICMP']
        if args.mode=='direct' and not args.baseline:
            assert 'Post-enable translation, dynamic map/unmap and RAM alias probe passed' in g.text()
            result['checks']+=['MMU permissions, guard pages and dynamic aliases with 512 MiB RAM']
        if args.no_usb or args.empty_usb:
            assert g.symbol('online')==0
            before=g.symbol('tick_count');ticks=g.cpu_ticks();started=time.monotonic()
            g.screen('no-input-desktop');time.sleep(3)
            wait(lambda:g.symbol('view')==4,8,'automatic driver diagnostics without keyboard/pointer')
            page=g.symbol('driver_report_page');g.screen('automatic-drivers-page1')
            if g.symbol('driver_report_pages')>1:
                wait(lambda:g.symbol('driver_report_page')!=page,5,'diagnostic pages rotate without input')
            g.screen('automatic-drivers-page2')
            assert g.symbol('tick_count')>before,'timer must keep progressing without input devices'
            result['idle_cpu_percent']=round(100*(g.cpu_ticks()-ticks)/os.sysconf('SC_CLK_TCK')/(time.monotonic()-started),2)
            assert result['idle_cpu_percent']<20,'missing input must not introduce a busy loop'
            result['checks']+=['desktop leaves splash with '+('absent controller' if args.no_usb else 'empty xHCI controller'),'timer progress and low idle CPU without input','automatic rotating diagnostics without input']
            result['status']='PASS';return 0
        def motion(x,y):
            if args.tablet:
                xx=max(0,min(799,g.symbol('mouse_x')+x));yy=max(0,min(599,g.symbol('mouse_y')+y))
                g.qmp('input-send-event',events=[{'type':'abs','data':{'axis':'x','value':round(xx*32767/799)}},
                                                {'type':'abs','data':{'axis':'y','value':round(yy*32767/599)}}])
            else:
                g.qmp('input-send-event',events=[{'type':'rel','data':{'axis':'x','value':x}},{'type':'rel','data':{'axis':'y','value':y}}])
            time.sleep(.04)
        before=g.screen('desktop');t=time.monotonic();g.hmp('sendkey c')
        wait(lambda:g.screen('console')!=before,2,'keyboard shortcut visible response')
        result['keyboard_visible_ms']=round((time.monotonic()-t)*1000,2)
        if args.mode!='direct':
            g.type('echo ',enter=False)
            for _ in range(32):
                g.qmp('input-send-event',events=[{'type':'key','data':{'down':True,'key':{'type':'qcode','data':'b'}}}]);time.sleep(.007)
                g.qmp('input-send-event',events=[{'type':'key','data':{'down':False,'key':{'type':'qcode','data':'b'}}}]);time.sleep(.007)
            g.hmp('sendkey ret');wait(lambda:('b'*32) in g.terminal(),3,'32 fast native USB keypress/release pairs')
            result['checks']+=['32 fast USB keypress/release pairs']
        if args.clock_test:
            if args.mode!='direct':
                g.type('clock');first=int(re.findall(r'Unix seconds: (\d+)',g.terminal())[-1])
                time.sleep(2);g.type('clock');second=int(re.findall(r'Unix seconds: (\d+)',g.terminal())[-1])
                assert second>first>1577836800,'wall clock must advance independently of GUI input'
                assert 'UEFI GetTime snapshot' in g.terminal()
            def taskbar_clock(name):
                pixels=g.screen(name,full=True)
                return b''.join(pixels[(row*800+716)*3:(row*800+799)*3] for row in range(574,598))
            initial_clock=taskbar_clock('clock-before')
            def minute_changed():
                time.sleep(.2);return taskbar_clock('clock-progress')!=initial_clock
            wait(minute_changed,65,'visible taskbar clock minute rollover')
            result['checks']+=['UEFI clock snapshot/counter progress and visible minute rollover' if args.mode!='direct' else 'FDT RTC progress and visible minute rollover']
        if args.pci_virtio:
            wait(lambda:g.symbol('net_state')==3,15,'selected Ethernet DHCP lease')
            assert ('[OK] CHFS filesystem mounted on NVMe.' if args.nvme else '[OK] UEFI VirtIO/CHFS mounted.') in g.text()
            g.type('write /stage1.txt pci-persistence')
            if args.storage_error:
                wait(lambda:'Write failed:' in g.terminal(),5,'NVMe write failure surfaced in Console')
                g.type('echo storage-failure-responsive')
                wait(lambda:'storage-failure-responsive' in g.terminal(),3,'GUI responsive after real storage error')
            else:
                wait(lambda:'File written and flushed.' in g.terminal(),5,'PCI CHFS write and flush')
                g.type('type /stage1.txt')
                wait(lambda:'pci-persistence' in g.terminal(),3,'PCI CHFS read')
            g.type('rng-test');g.type('rng-test')
            expected='Entropy unavailable:' if args.no_rng else 'Received 32 hardware entropy bytes.'
            wait(lambda:expected in g.terminal(),3,'PCI entropy hardware receipt or explicit absence')
            g.type('ping 10.0.2.2')
            next_status=[0.0]
            def gui_ping_replied():
                if time.monotonic()>next_status[0]:
                    g.type('netstatus');next_status[0]=time.monotonic()+.5
                return 'Ping: reply received' in g.terminal()
            wait(gui_ping_replied,10,'PCI VirtIO ARP/ICMP reply')
            (out/'pci-console.txt').write_text(g.terminal());g.screen('pci-diagnostics')
            result['checks']+=[('NVMe injected write failure and responsive GUI' if args.storage_error else 'NVMe CHFS write/flush/read') if args.nvme else 'PCI VirtIO CHFS write/flush/read','PCI VirtIO hardware RNG' if not args.no_rng else 'PCI RNG absent fails explicitly',({'vmxnet3':'VMXNET3','e1000e':'82574L e1000e','virtio':'PCI VirtIO'}[args.net_model]+' DHCP/ARP/ICMP')]
        before=g.screen('pointer-before');t=time.monotonic()
        motion(-200,150)
        wait(lambda:g.screen('pointer-after')!=before,2,'pointer visible response')
        result['pointer_visible_ms']=round((time.monotonic()-t)*1000,2)
        result['checks']+=['keyboard shortcut','absolute tablet' if args.tablet else 'relative pointer']
        if not args.baseline:
            wheel=g.symbol('chos_input_diagnostics',24)
            for button_name in ['wheel-up','wheel-down']:
                g.qmp('input-send-event',events=[{'type':'btn','data':{'button':button_name,'down':True}},
                                                {'type':'btn','data':{'button':button_name,'down':False}}])
                time.sleep(.1)
            wait(lambda:g.symbol('chos_input_diagnostics',24)>=wheel+2,2,'actual wheel reports reach shared input')
            result['checks']+=['wheel reports through hardware transport to shared input']
        def move_to(x,y):
            if args.tablet:
                g.qmp('input-send-event',events=[{'type':'abs','data':{'axis':'x','value':math.ceil(x*32767/799)}},
                                                {'type':'abs','data':{'axis':'y','value':math.ceil(y*32767/599)}}])
                time.sleep(.06);return
            # Saturate to the top-left through real relative reports, then move
            # in chunks below both USB's signed 8-bit and GUI delta bounds.
            for _ in range(9): motion(-100,-100)
            while x or y:
                dx=min(100,x);dy=min(100,y);motion(dx,dy);x-=dx;y-=dy
        def button(down):
            g.qmp('input-send-event',events=[{'type':'btn','data':{'button':'left','down':down}}]);time.sleep(.06)
        # Maximize/restore is the desktop's implemented resize operation.
        original=g.window()
        assert original['id']!=0,'keyboard shortcut must open Console, not merely change splash/clock pixels'
        move_to(original['x']+original['width']-38,original['y']+13)
        before=g.screen('maximize-before');t=time.monotonic()
        button(True);button(False)
        wait(lambda:g.window()['id']==original['id'] and g.window()['maximized'],2,'maximize foreground window')
        after=g.screen('maximize-after')
        assert sum(a!=b for a,b in zip(before,after))>20000
        result['maximize_visible_ms']=round((time.monotonic()-t)*1000,2)
        maximized=g.window()
        move_to(maximized['x']+maximized['width']-38,maximized['y']+13)
        button(True);button(False)
        wait(lambda:g.window()==original,2,'restore exact foreground window geometry')
        move_to(original['x']+100,original['y']+13)
        before=g.screen('drag-before');t=time.monotonic()
        button(True);motion(50,40);button(False)
        wait(lambda:g.window()['id']==original['id'] and (g.window()['x'],g.window()['y'])!=(original['x'],original['y']),2,'move same window by title bar')
        after=g.screen('drag-after')
        assert sum(a!=b for a,b in zip(before,after))>20000
        result['drag_visible_ms']=round((time.monotonic()-t)*1000,2)
        result['checks']+=['window maximize/restore','title-bar drag']
        if args.mode!='direct':
            # More than one producer/event-ring wrap; no controller reset
            # between these actual slot disable/address/configure operations.
            current='mouse'
            for i in range(20):
                g.qmp('device_del',id=current);time.sleep(.12)
                current='mouse'+str(i)
                g.qmp('device_add',driver='usb-tablet' if args.tablet else 'usb-mouse',bus=g.usb_bus,id=current,**({'port':g.mouse_port} if g.mouse_port else {}));time.sleep(.25)
            before=g.screen('reconnect-before');motion(100,0)
            wait(lambda:g.screen('reconnect-after')!=before,2,'hot-reconnected mouse after 20 cycles')
            result['checks']+=['20 USB hot-unplug/reconnect cycles with ring wraps']
            if args.hub_depth:
                g.qmp('input-send-event',events=[{'type':'key','data':{'down':True,'key':{'type':'qcode','data':'shift'}}}])
                wait(lambda:g.symbol('shift_down')==1,2,'held USB modifier before hub unplug')
                button(True)
                g.qmp('device_del',id='hub0')
                wait(lambda:g.symbol('online')==0,3,'whole hub subtree teardown')
                wait(lambda:g.symbol('shift_down')==0 and g.symbol('left_button_down')==0,2,'release held inputs on subtree removal')
                path='1'
                for depth in range(args.hub_depth):
                    g.qmp('device_add',driver='usb-hub',id='rehub'+str(depth),bus='xhci.0',port=path)
                    if depth+1<args.hub_depth:path+='.1'
                g.qmp('device_add',driver='usb-kbd',bus='xhci.0',port=path+'.1',id='rekbd')
                g.qmp('device_add',driver='usb-tablet' if args.tablet else 'usb-mouse',bus='xhci.0',port=path+'.2',id='remouse')
                wait(lambda:g.symbol('online')==2,5,'whole hub subtree re-enumeration')
                g.qmp('input-send-event',events=[{'type':'key','data':{'down':False,'key':{'type':'qcode','data':'shift'}}}])
                before=g.screen('rehub-before');motion(-80,30)
                wait(lambda:g.screen('rehub-after')!=before,2,'input after whole hub reconnect')
                result['checks']+=['whole hub subtree unplug/reconnect and held-key/button release']

        if args.stress:
            stress_started=time.monotonic()
            # Mixed traffic through real input hardware; each command performs a
            # persistent filesystem transaction and flush before the next cycle.
            for i in range(args.stress):
                if args.pci_virtio and not args.storage_error:
                    g.type('write /stress.txt cycle-'+str(i))
                motion((-1 if i%2 else 1)*40,(-1 if i%3 else 1)*20)
                if i%10==0:g.screen('stress-'+str(i))
            if args.pci_virtio and not args.storage_error:
                g.type('type /stress.txt')
                wait(lambda:'cycle-'+str(args.stress-1) in g.terminal(),5,'last stress transaction readable')
            result['stress_seconds']=round(time.monotonic()-stress_started,3)
            result['checks']+=[str(args.stress)+' mixed input/storage cycles']
        ticks=g.cpu_ticks();start=time.monotonic();time.sleep(2)
        result['idle_cpu_percent']=round(100*(g.cpu_ticks()-ticks)/os.sysconf('SC_CLK_TCK')/(time.monotonic()-start),2)
        result['checks']+=['2-second idle observation']
        if args.mode=='direct' or (args.pci_virtio and not args.storage_error):
            g.close();g=None
            # Second fresh machine on the same disposable disk checks persistence.
            reboot=out/'reboot';reboot.mkdir()
            reboot_args=argparse.Namespace(**vars(args))
            reboot_args.kernel=out/'kernel.elf';reboot_args.uefi_kernel=out/'kernel.elf'
            if args.mode=='uefi':reboot_args.iso=out/'boot.iso'
            g=Guest(reboot_args,reboot,disk)
            if args.mode=='direct':
                wait(lambda:'chos> ' in g.text(),45,'second boot');g.serial('fsread /STAGE1.TXT')
                wait(lambda:'stage1-persistence' in g.text(),5,'CHFS persisted after restart')
            else:
                wait(lambda:'[OK] Initial CHOS GUI frame rendered.' in g.text(),45,'second boot')
                wait(lambda:g.symbol('splash_active')==0,10,'second desktop')
                g.hmp('sendkey c');time.sleep(.2);g.type('type /stage1.txt')
                wait(lambda:'pci-persistence' in g.terminal(),5,'PCI CHFS persisted after restart')
            result['checks']+=['storage persistence after fresh guest boot']
        result['status']='PASS'
    except Exception as e:
        result['status']='FAIL';result['error']=str(e)
        if g and not args.baseline:
            result['input_counters']={k:g.symbol('chos_input_diagnostics',offset) for k,offset in [('keys',0),('buttons',8),('relative',16),('wheel',24)]}
            result['guest_view']=g.symbol('view')
            if args.pci_virtio:
                result['virtio_devices']=g.qmp('x-query-virtio')
                result['network_debug']={name:g.block(name,size=size).hex() for name,size in [('net_state',112),('net_info',112),('tx_used',24),('rx_used',32)]}
    finally:
        if g:g.close()
        (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
