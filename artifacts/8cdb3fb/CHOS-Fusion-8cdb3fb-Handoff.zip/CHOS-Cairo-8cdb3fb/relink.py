#!/usr/bin/env python3
import argparse,pathlib,json,hashlib,subprocess
root=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser(description="Relink the actual isolated Cairo executable from supplied objects and libraries")
p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--cc',default='clang')
p.add_argument('--allow-modified',action='store_true',help='Intentionally relink user-modified libraries/objects; do not claim original qualification')
o=p.parse_args();out=o.output.resolve();assert not out.exists(),'Choose a new output file'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if not o.allow_modified:
    for name,wanted in json.loads((root/'MANIFEST.json').read_text())['files'].items():
        file=root/name;assert file.is_file() and not file.is_symlink() and file.resolve().is_relative_to(root)
        assert file.stat().st_size==wanted['bytes'] and sha(file)==wanted['sha256'],name
record=json.loads((root/'relink-argv.json').read_text())
args=[arg.replace('@KIT@',str(root)).replace('@OUTPUT@',str(out)) for arg in record['argv']];args[0]=o.cc
subprocess.run(args,cwd=root,check=True)
actual=sha(out);matches=actual==record['expected_elf_sha256']
print(json.dumps({'output':str(out),'sha256':actual,'matches_original':matches,'user_modified':o.allow_modified},indent=2))
assert matches or o.allow_modified,'Relink differs from the qualified original'
