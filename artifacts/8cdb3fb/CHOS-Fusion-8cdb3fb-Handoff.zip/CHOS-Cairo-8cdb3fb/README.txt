CHOS Cairo development test milestone
Source commit: 8cdb3fb2fb8217bbda8d9d3104be1ff11efe2694

Stage 3 is incomplete; version remains 0.30.0. This is a real software graphics diagnostic, not a modern browser.
This software uses FreeType. Cairo/pixman/FreeType/font and SDK notices are supplied, with original corresponding sources in SOURCE.zip.

Use FUSION-TESTING.md. The separate Native-Cairo ISO has no installer. Normal Fusion installation media are included independently.

The complete original SDK, actual static graphics/font archives, application objects, native ELF and portable link arguments are supplied. With AArch64 Clang/LLD in PATH, run python3 relink.py --output /new/native_cairo.elf. The unmodified result must match exactly. --allow-modified permits intentionally changed libraries/objects without asserting original qualification.

To rebuild libraries, extract SOURCE.zip, use the supplied SDK with tools/build_native_text.py to build a fresh font prefix, then tools/build_native_graphics.py with that prefix. Existing exported .pc/CMake metadata retains original absolute build paths; full source rebuilds generate fresh paths. Relinking uses explicit portable archive paths and needs no host libraries. Kernel/ISO build and staging instructions are in docs/NATIVE_CAIRO_RENDERING.md.

SDK archives not imported by this executable are retained as complete original SDK inputs; source/notice scope and preceding SDK compilation provenance remain explicit in the manifests. QEMU evidence does not certify new Fusion/Pi5/laptop behavior.
