CHOS revised Stage 3 network milestone 54b9731
Source commit: 54b97319a7abb6746eff491f167a82f00c08c08d

This is an in-progress Stage3 NETWORK milestone, not completion of the revised
modern browser/Wi-Fi/secure internet platform. The revised prompt supersedes the
Word document's Stage3; it is included in docs. Modern rendering/JavaScript/TLS,
Wi-Fi, IPv6 and an isolated UEFI browser runtime remain open.

Fusion's actual PCI8086:10d3 Intel82574L now has an e1000e backend. Source preserves
VirtIO and VMXNET3. QEMU validates real traffic for all three, including Ethernet,
DHCP/DNS/HTTP/relative redirects, link loss and automatic reconnect. Actual new
Fusion traffic remains untested here. Keep the VM's network adapter connected,
using its existing working host NAT/bridge policy; choose automatic DHCP in CHOS.

Open Network Manager from the tray icon, desktop N shortcut or Settings->Network.
Choose DHCP/static/disconnected, edit IPv4/mask/gateway/DNS, Apply and Keep. Changes
revert after30seconds unless confirmed. Save persists to writable CHFS with CRC,
MAC binding, flush/readback and reboot checks. Unsupported Wi-Fi/IPv6 are explicit.
A configured interface is not reported as proven Internet connectivity.

EL0 applications have a read-only network-status syscall. Normal application
filesystem mutation cannot overwrite/delete/move the service profile or parent.
A real EL0 app verifies status-buffer validation and profile protection. This
is not a complete browser sandbox. The old HTTP preview stays recovery-only;
HTTPS remains blocked, without certificate-verification bypass or downgrade.

Restart/power-off, five-second shutdown, automatic installed writes, hidden Setup,
Console scrollback and genuine installer remain. Use one CPU/2GiB and a disposable
NVMe disk. Existing installs do not auto-update: reinstall erases the selected disk.
Preserve your current VM/data or use a new virtual disk to evaluate this ISO.

All included clean-build QEMU profiles pass. Host and ASan/UBSan suites pass.
Engine-prerequisite probe output lists real missing runtime facilities; it is NOT
an engine build or standards-conformance pass. See STAGE3_NETWORK_RESULTS.json,
NETWORK_MANAGER.md, STAGE3_ARCHITECTURE.md and BROWSER_ENGINE_PORT.md.

No mutated test disks, firmware variables, packet captures or credentials are
included. Optional prepared.img.gz is the official generated distribution image.
Verify SHA256SUMS and decompress .gz files before use.
