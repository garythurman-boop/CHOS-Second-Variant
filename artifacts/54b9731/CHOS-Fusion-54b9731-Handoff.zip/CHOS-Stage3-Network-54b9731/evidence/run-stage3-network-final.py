import subprocess,pathlib,json
root=pathlib.Path('/workspace/CHOS-Second-Variant');out=pathlib.Path('/workspace/chos-evidence')
fw='/workspace/chos-tools/root/usr/share/AAVMF/AAVMF_CODE.fd';data='/workspace/chos-tools/root/usr/share/qemu'
for elf in ['build/chos.elf','build/uefi-kernel/chos.elf']:
 b=(root/elf).read_bytes();assert b'[BUILD] 54b97319a7ab\n\0' in b and b'54b97319a7ab-dirty' not in b
cases=[
 ('stage3-e1000-http',['tests/qemu_network.py','--net-model','e1000e']),
 ('stage3-manager-e1000',['tests/qemu_net_manager.py']),
 ('stage3-manager-vmx',['tests/qemu_net_manager.py','--net-model','vmxnet3']),
 ('stage3-manager-virtio',['tests/qemu_net_manager.py','--net-model','virtio']),
 ('stage3-net-policy',['tests/qemu_net_policy.py']),
 ('stage3-vmx-http',['tests/qemu_network.py','--net-model','vmxnet3']),
 ('stage3-virtio-http',['tests/qemu_network.py','--net-model','virtio']),
 ('stage3-console-uefi',['tests/qemu_console.py']),
 ('stage3-console-direct',['tests/qemu_console.py','--mode','direct']),
 ('stage3-install',['tests/qemu_installer.py','--keyboard','--supported-mode']),
 ('stage3-install-error',['tests/qemu_installer.py','--write-fault']),
 ('stage3-native-e1000',['tests/qemu_platform.py','--mode','uefi','--pci-virtio','--net-model','e1000e','--tablet','--memory','2G','--hub-depth','2','--firmware',fw,'--qemu-data',data]),
 ('stage3-direct',['tests/qemu_platform.py','--qemu-data',data]),
]
results=[]
for name,args in cases:
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['python3']+args+['--out',str(out/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit_code':r.returncode});(out/'stage3-final-runs.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True)
