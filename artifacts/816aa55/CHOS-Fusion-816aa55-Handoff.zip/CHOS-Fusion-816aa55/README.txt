CHOS Fusion correction candidate 816aa55
Source commit: 816aa553adb2b81bcd942d3e7be26a9eb6e0664a

Boot CHOS-Fusion-816aa55.iso in the same Fusion ARM64 UEFI VM (one CPU, 2 GiB RAM).
This corrects MMU-off exclusive-access faults and recursive panic reporting.
Actual Fusion boot/input/clock acceptance is NOT claimed; the cloud cannot run Fusion.
Keep the two CHOS projects separate. NVMe remains disabled in this standard build.

Test desktop entry, clock advancement, typing/Shift, pointer/buttons/wheel,
drag/maximize/restore and reconnect. If input is missing, wait for automatic
rotating driver reports and capture them. If a panic occurs, the stable page now
includes a build revision, relocated image base and PC offset; capture that page.

Source, direct/UEFI kernels, EFI loader, official prepared image and test evidence
are included. Decompress .gz files before use. Never write the prepared image over
a valuable disk. Per-test mutable disks and firmware variable files are excluded.
Verify SHA256SUMS at this archive's top level after extraction.

The exact clean ISO and kernel bytes pass native NEC xHCI on PCI bus 10 through
two hubs, tablet/keyboard/wheel, 32 fast key pairs, 20 reconnects, held-state release,
clock rollover, PCI VirtIO storage/network/RNG and persistence after a new guest.
Direct boot/EL0 RNG, full host regression, ASan/UBSan and serial smoke also pass.
Two deliberate panic-injection VMs pass with unusable SP, held UART lock,
UART attached/absent and a second synchronous BRK: first record and screen stay fixed.
See evidence/FINAL_RESULTS.json and docs/FUSION_PANIC_2ED3E6D.md in the source ZIP.

Rebuild with Clang/LLD, LLVM binary tools, Python 3 and QEMU/AAVMF:
  make CC=clang LD=ld.lld -j4 all uefi-iso install-disk-image
  make test CC=clang LD=ld.lld -j1
  make test-sanitize CC=clang LD=ld.lld -j1
  make qemu-smoke CC=clang LD=ld.lld
The source export builds identify themselves as source-export without Git metadata.
