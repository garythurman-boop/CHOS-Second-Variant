CHOS Fusion correction — 2ed3e6d571dfd5988b1a5b15774ffe0e553a8e5f

Use CHOS-Fusion-2ed3e6d.iso in the same Fusion ARM64 VM (one CPU, 2 GiB RAM).
This final image supersedes the early 81e3550 and e7fb4a8 candidates. Boot diagnostics identify
[BUILD] 2ed3e6df9900. The standard ISO keeps experimental NVMe probing disabled.
The prepared disk image is optional and intended for a disposable virtual disk.

Changes: firmware GetTime snapshot/counter clock; narrowly matched VMware compact
xHCI version compatibility; EP0 packet learning and actual Data Stage completions;
correct reserved input-context fields; independent composite HID functions and bounded endpoint-padded reports; queued
interrupt receives, shared held-key/button ownership and absolute-pointer preference;
modular driver admission/polling and automatic input-free diagnostics.

Verify clock advancement, keyboard typing including Shift+letters, pointer/buttons/
wheel, window drag/maximize/restore, and reconnects. Console C, then clock, drivers,
pci and bootlog give detailed status. If keyboard or pointer admission is missing,
wait five seconds after startup: Diagnostics opens automatically and rotates pages.
Capture the pages showing PCI IDs, selected driver/refusal, xHCI CAP/HCS/HCC, USB
stage/failure/root/route and control requested/received/completion. No serial port,
keypress, storage or separate diagnostic ISO is needed.

Actual Fusion runtime confirmation of THIS image remains pending. The reported
previous build reaches desktop with broken input/clock. The user-owned separate
Test-CHOS project's tested patterns and recorded Fusion facts informed these fixes;
that repository remains separate and unchanged. Its MIT notice is retained.

Local acceptance passes clean direct/UEFI/prepared builds, host regressions and
sanitizers, native USB/PCI and direct MMIO paths, visible clock rollover, 32 fast
keypress/release pairs, hotplug/held-release and persistence. A 120-cycle mixed
stress run passed over 191.908 seconds. A second NEC controller behind PCI bus 0a
also passes. These are QEMU tests, not VMware runs. Deliberately broken timer IRQ
routing is tested through polling/counter recovery and consumes a full CPU; normal
idle observations are low. Read docs/FUSION_DRIVER_FIXES.md for evidence and limits.

The source archive includes the original historical prebuilt directory. Use the
revision-labelled binaries in THIS package or rebuild current main for these fixes.
Source: https://github.com/garythurman-boop/CHOS-Second-Variant
