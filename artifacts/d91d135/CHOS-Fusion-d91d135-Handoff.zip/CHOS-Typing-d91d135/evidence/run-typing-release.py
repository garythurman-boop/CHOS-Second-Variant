from pathlib import Path
import subprocess,json,concurrent.futures
root=Path('/workspace/CHOS-Second-Variant');ev=Path('/workspace/chos-evidence')
cases=[('typing-release-uefi',['tests/qemu_typing.py']),('typing-release-direct',['tests/qemu_typing.py','--mode','direct']),('typing-release-console-uefi',['tests/qemu_console.py']),('typing-release-console-direct',['tests/qemu_console.py','--mode','direct']),('typing-release-e1000',['tests/qemu_network.py','--net-model','e1000e']),('typing-release-install',['tests/qemu_installer.py','--keyboard','--supported-mode']),('typing-release-platform',['tests/qemu_platform.py','--qemu-data','/workspace/chos-tools/root/usr/share/qemu']),('typing-release-memory',['tests/qemu_user_memory.py']),('typing-release-policy',['tests/qemu_net_policy.py'])]
def run(item):
 name,args=item
 with (ev/(name+'.log')).open('w') as log:p=subprocess.run(['python3']+args+['--out',str(ev/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True);return {'name':name,'exit_code':p.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,cases))
(ev/'typing-release-runs.json').write_text(json.dumps(results,indent=2))
raise SystemExit(any(r['exit_code'] for r in results))
