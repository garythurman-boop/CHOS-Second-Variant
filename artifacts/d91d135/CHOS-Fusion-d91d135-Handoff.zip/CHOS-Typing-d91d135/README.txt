CHOS held-key repeat and blinking text caret build d91d135
Source commit: d91d135f4e5b14078384b954ccb10cdec590cc53

USB/VirtIO shared typematic: 500ms initial delay, then25Hz; bounded/no catch-up
burst. Backspace/letters/navigation repeat. Release, disconnect, pointer/focus/modal
transitions cancel. No repeated Enter/Escape/admin shortcuts. Active Console,
text documents, browser address bar, naming dialogs and editable network fields
have500ms caret blinking. Long address edits show their tail. A validated window-
owned caret service handles EL0 applications. Browser idle pages no longer rebuild
every tick. See docs/TEXT_INPUT.md.

Fusion Ethernet/example.com is now USER-CONFIRMED after previous54b9731 build.
Preserve that adapter: PCI8086:10d3 Intel82574L. New typing changes have QEMU tests
but still need an independent Fusion test. Installer/storage/restart/power-off,
Console scrollback, NetworkManager and guarded direct-EL0 memory remain.

This is NOT completion of revised Stage3. Modern engine/JavaScript/CSS rendering,
TLS/trust/secure entropy, UEFI isolation, IPv6, multiple interfaces and real Pi5
wireless remain open. First WiFi target is Pi5 CYW43455 SDIO2, verified against
RaspberryPiOS firmware mappings; selecting the chip is not a working driver.
No fake WiFi or TLS verification bypass is included. The HTTP preview is recovery
functionality. See docs/PI5_WIRELESS.md and revised-stage architecture.

All9 clean-build guest profiles pass; aggregate host/sanitizers and direct smoke
pass. Input tests include real USB/VirtIO held keys, visible blink/newline and USB
unplug release. Live e1000e DHCP/DNS/HTTP, installer/disk-only boot/persistence/reset/
>=5s shutdown, EL0 memory faults/cleanup and profile access protection pass.

Use a disposable VM/disk. Existing installs do not auto-update; reinstall erases
the selected disk. No per-test disks, firmware-variable files or credentials are
in this package. Published ISO, prepared image and kernels are separate assets.
